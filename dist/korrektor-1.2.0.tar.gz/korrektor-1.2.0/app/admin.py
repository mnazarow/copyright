# -*- coding: utf-8 -*-
"""Страницы администратора: пользователи и роли, журнал действий; личный кабинет (смена пароля)."""
import csv
import io

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from starlette.concurrency import run_in_threadpool

from . import core, notify, users
from .pipeline.exports import safe

router = APIRouter()
_tpl = None
_ctx = None


def setup(app, tpl, ctx):
    global _tpl, _ctx
    _tpl, _ctx = tpl, ctx
    app.include_router(router)


def me(request):
    return getattr(request.state, "user", None) or {}


# ------------------------------------------------------------------ пользователи
@router.get("/admin/users", response_class=HTMLResponse)
def users_page(request: Request, saved: str = "", error: str = ""):
    rows = [{k: v for k, v in u.items() if k != "pw"} for u in users.all_users()]     # хэши паролей не попадают в страницу
    with core.db() as c:
        counts = {r[0]: r[1] for r in c.execute("SELECT owner, COUNT(*) FROM jobs GROUP BY owner")}
    return _tpl.TemplateResponse(request, "admin_users.html", _ctx(request, "admin", rows=rows, counts=counts,
                                                                   saved=saved, error=error))


@router.post("/admin/users/save")
def users_save(request: Request, login: str = Form(...), name: str = Form(""), role: str = Form("author"),
               password: str = Form(""), email: str = Form(""), department: str = Form(""), active: str = Form("")):
    login = login.strip()
    if password:
        prob = users.pw_problem(password)
        if prob:
            return RedirectResponse("/admin/users?error=" + prob, status_code=303)
    try:
        existing = users.get(login)
        if existing and existing["source"] != "local" and password:
            raise ValueError("Пароль пользователя LDAP хранится в домене, его меняют там")
        if not existing and not password:
            raise ValueError("Для нового пользователя задайте пароль")
        if existing and existing["login"].lower() == me(request).get("login", "").lower() and (role != "admin" or not active):
            raise ValueError("Нельзя снять с себя роль администратора или отключить свою учетную запись")
        users.save(login, name.strip()[:120], role, password or None, active=1 if active else 0,
                   email=email.strip()[:200], department=department.strip()[:120],
                   source=existing["source"] if existing else "local")
    except ValueError as e:
        return RedirectResponse("/admin/users?error=" + str(e), status_code=303)
    users.audit(request, "user_save", login, {"role": role, "active": bool(active), "password": bool(password)})
    return RedirectResponse("/admin/users?saved=" + login, status_code=303)


@router.post("/admin/users/delete")
def users_delete(request: Request, login: str = Form(...)):
    if login.lower() == me(request).get("login", "").lower():
        return RedirectResponse("/admin/users?error=Нельзя удалить самого себя", status_code=303)
    users.delete(login)
    users.audit(request, "user_delete", login)
    return RedirectResponse("/admin/users?saved=удален", status_code=303)


# ------------------------------------------------------------------ журнал
@router.get("/admin/audit", response_class=HTMLResponse)
def audit_page(request: Request, q: str = "", user: str = "", action: str = "", page: int = 1):
    page = max(1, page)
    total, rows = users.audit_rows(q, user, action, 100, (page - 1) * 100)
    with core.db() as c:
        who = [r[0] for r in c.execute("SELECT DISTINCT user FROM audit WHERE user<>'' ORDER BY user")]
    return _tpl.TemplateResponse(request, "admin_audit.html", _ctx(
        request, "admin", rows=rows, total=total, q=q, fuser=user, faction=action, pageno=page,
        pages=max(1, (total + 99) // 100), who=who, names=users.AUDIT_NAMES))


@router.get("/admin/audit/export")
def audit_export(q: str = "", user: str = "", action: str = ""):
    _, rows = users.audit_rows(q, user, action, 100000, 0)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["Время", "Пользователь", "Адрес", "Действие", "Объект", "Подробности"])
    for r in rows:
        w.writerow([safe(x) for x in (r["ts"], r["user"], r["ip"], users.AUDIT_NAMES.get(r["action"], r["action"]),
                                      r["target"], r["detail"])])
    return Response("﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=korrektor_audit.csv"})


# ------------------------------------------------------------------ личный кабинет
@router.get("/account", response_class=HTMLResponse)
def account_page(request: Request, saved: int = 0, error: str = ""):
    u = me(request)
    with core.db() as c:
        mine = c.execute("SELECT COUNT(*) FROM jobs WHERE owner=?", (u.get("login", ""),)).fetchone()[0]
    return _tpl.TemplateResponse(request, "account.html", _ctx(request, "account", saved=saved, error=error, mine=mine))


@router.post("/account/password")
def account_password(request: Request, old: str = Form(""), new: str = Form(""), new2: str = Form("")):
    u = me(request)
    if u.get("source") != "local":
        return RedirectResponse("/account?error=Пароль этой учетной записи меняется не здесь "
                                "(администратор — командой sudo korrektor passwd, LDAP — в домене)", status_code=303)
    full = users.get(u["login"])
    if not users.verify_pw(old, full.get("pw", "")):
        return RedirectResponse("/account?error=Текущий пароль указан неверно", status_code=303)
    if new != new2:
        return RedirectResponse("/account?error=Новые пароли не совпадают", status_code=303)
    prob = users.pw_problem(new)
    if prob:
        return RedirectResponse("/account?error=" + prob, status_code=303)
    users.save(u["login"], full["name"], full["role"], new, active=full["active"], email=full["email"],
               department=full["department"])
    users.audit(request, "password", u["login"])
    # пароль сменился — прежние сеансы (в том числе чужие) больше не действуют; текущему выдаем новый
    hours = int(core.load_settings().get("session_hours") or 336)
    r = RedirectResponse("/account?saved=1", status_code=303)
    r.set_cookie("korrektor", core.make_token(u["login"], hours * 3600, users.session_stamp(users.get(u["login"]))),
                 httponly=True, samesite="lax", max_age=hours * 3600,
                 secure=request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https")
    return r


@router.post("/account/profile")
def account_profile(request: Request, name: str = Form(""), email: str = Form(""), department: str = Form("")):
    u = me(request)
    if u.get("source") not in ("local", "ldap"):
        raise HTTPException(400, "Профиль встроенного администратора не редактируется")
    full = users.get(u["login"])
    try:
        users.save(u["login"], name.strip()[:120], full["role"], None, active=full["active"], email=email.strip()[:200],
                   department=department.strip()[:120])
    except ValueError as e:
        return RedirectResponse("/account?error=" + str(e), status_code=303)
    return RedirectResponse("/account?saved=1", status_code=303)


# ------------------------------------------------------------------ проверки связи
@router.post("/settings/test-ldap")
async def test_ldap(request: Request):
    form = await request.form()
    st = core.load_settings()
    ok, info = await run_in_threadpool(users.ldap_bind, form.get("login", ""), form.get("password", ""), st)
    if ok:
        return {"ok": True, "answer": "вход выполнен" + (f": {info.get('name')}, {info.get('email')}" if info else "")}
    return {"ok": False, "error": {"bad": "неверный логин или пароль", "unavailable": "сервер LDAP недоступен или не "
                                   "установлен модуль ldap3 (см. журнал службы)", "empty": "введите логин и пароль"}.get(info, str(info))}


@router.post("/settings/test-notify")
async def test_notify(request: Request):
    st = core.load_settings()
    res = await run_in_threadpool(notify.send_test, st)
    return JSONResponse({"ok": all(v == "ok" for v in res.values()) and bool(res),
                         "answer": "; ".join(f"{k}: {v}" for k, v in res.items()) or "ни один канал не включен",
                         "error": "; ".join(f"{k}: {v}" for k, v in res.items()) or "ни один канал не включен"})


# ------------------------------------------------------------------ сравнение версий
@router.get("/compare", response_class=HTMLResponse)
def compare_page(request: Request, a: int = 0, b: int = 0, job: int = 0):
    from . import compare
    if job and not (a and b):
        a, b = compare.default_pair(job)
        a, b = a or 0, b or 0
    res = compare.compare(a, b) if a and b and a != b else None
    pivot = b or a or job
    same, other = compare.candidates(pivot) if pivot and core.get_job(pivot) else ([], [])
    return _tpl.TemplateResponse(request, "compare.html", _ctx(request, "jobs", res=res, a=a, b=b, same=same,
                                                               other=other, pivot=core.get_job(pivot) if pivot else None))


@router.get("/api/compare")
def compare_api(a: int, b: int):
    from . import compare
    res = compare.compare(a, b)
    if not res:
        raise HTTPException(404, "Оба задания должны быть готовы")
    return {k: (len(v) if isinstance(v, list) and k in ("fixed", "remain", "hidden", "new") else v) for k, v in res.items()
            if k not in ("a", "b")} | {"a": a, "b": b, "details": compare.rows_csv(res)}


@router.get("/compare/export")
def compare_export(a: int, b: int):
    from . import compare
    res = compare.compare(a, b)
    if not res:
        raise HTTPException(404)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    from .pipeline.exports import safe
    for r in compare.rows_csv(res):
        w.writerow([safe(x) for x in r])
    name = f"сравнение_{a}_{b}.csv"
    from urllib.parse import quote
    return Response("﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})


@router.post("/settings/apply")
async def settings_apply(request: Request):
    """Изменить одну логическую настройку (кнопка в рекомендациях аналитики)."""
    from .settings_schema import SCHEMA
    body = await request.json()
    key = body.get("key") if isinstance(body, dict) else None
    if key not in SCHEMA or SCHEMA[key]["type"] != "bool":
        raise HTTPException(400, "Так можно менять только логические настройки (включено/выключено)")
    st = core.update_settings(lambda s: s.__setitem__(key, bool(body.get("value"))))
    users.audit(request, "settings", key, {key: st[key]})
    return {"ok": True, "key": key, "value": st[key], "title": SCHEMA[key]["title"]}


# ------------------------------------------------------------------ метрики Prometheus
@router.get("/metrics")
def metrics(request: Request):
    """Метрики в формате Prometheus. Доступ: с самого сервера (127.0.0.1) или с токеном REST API."""
    import hmac as _h
    import os
    import time as _t
    st = core.load_settings()
    host = request.client.host if request.client else ""
    tok = st.get("api_token")
    auth = request.headers.get("authorization", "")
    proxied = any(h in request.headers for h in ("x-forwarded-for", "x-real-ip", "forwarded"))
    if (proxied or host not in ("127.0.0.1", "::1", "localhost")) and not (tok and _h.compare_digest(auth.encode(), f"Bearer {tok}".encode())):
        return Response("доступ: с сервера или с заголовком Authorization: Bearer <токен API>\n", status_code=401,
                        media_type="text/plain; charset=utf-8")
    week = (__import__("datetime").datetime.now() - __import__("datetime").timedelta(days=7)).isoformat()
    with core.db() as c:
        by_status = dict(c.execute("SELECT status, COUNT(*) FROM jobs GROUP BY status").fetchall())
        done = c.execute("SELECT COUNT(*), COALESCE(SUM(pages),0), COALESCE(SUM(findings),0), COALESCE(SUM(verify_ok),0) "
                         "FROM jobs WHERE status='done'").fetchone()
        wk = c.execute("SELECT COUNT(*), COALESCE(SUM(pages),0), COALESCE(SUM(findings),0), COALESCE(SUM(verify_ok),0) "
                       "FROM jobs WHERE status='done' AND created>=?", (week,)).fetchone()
        dur = c.execute("SELECT started, finished FROM jobs WHERE status='done' AND started IS NOT NULL "
                        "ORDER BY id DESC LIMIT 200").fetchall()
        nusers = c.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
    import datetime as _dt
    secs = []
    for a, b in dur:
        try:
            secs.append((_dt.datetime.fromisoformat(b) - _dt.datetime.fromisoformat(a)).total_seconds())
        except (TypeError, ValueError):
            pass
    size = 0
    for root, _, files in os.walk(core.DATA):
        for fn in files:
            try:
                size += os.path.getsize(os.path.join(root, fn))
            except OSError:
                pass
    lines = [
        "# HELP korrektor_info Версия сервиса", "# TYPE korrektor_info gauge", f'korrektor_info{{version="{core.VERSION}"}} 1',
        "# HELP korrektor_jobs Задания по состоянию", "# TYPE korrektor_jobs gauge"]
    for s in ("queued", "running", "done", "failed", "uploading"):
        lines.append(f'korrektor_jobs{{status="{s}"}} {by_status.get(s, 0)}')
    lines += [
        "# HELP korrektor_pages_total Проверено страниц", "# TYPE korrektor_pages_total counter", f"korrektor_pages_total {done[1]}",
        "# HELP korrektor_findings_total Замечаний в отчетах", "# TYPE korrektor_findings_total counter", f"korrektor_findings_total {done[2]}",
        "# HELP korrektor_reports_verified_total Отчетов, прошедших 25 проверок", "# TYPE korrektor_reports_verified_total counter",
        f"korrektor_reports_verified_total {done[3]}",
        "# HELP korrektor_week_documents Документов за 7 дней", "# TYPE korrektor_week_documents gauge", f"korrektor_week_documents {wk[0]}",
        "# HELP korrektor_week_density Замечаний на 10 страниц за 7 дней", "# TYPE korrektor_week_density gauge",
        f"korrektor_week_density {round(10.0 * wk[2] / wk[1], 3) if wk[1] else 0}",
        "# HELP korrektor_week_verify_ratio Доля отчетов 25/25 за 7 дней", "# TYPE korrektor_week_verify_ratio gauge",
        f"korrektor_week_verify_ratio {round(wk[3] / wk[0], 4) if wk[0] else 1}",
        "# HELP korrektor_processing_seconds_avg Среднее время обработки (последние 200 заданий)",
        "# TYPE korrektor_processing_seconds_avg gauge", f"korrektor_processing_seconds_avg {round(sum(secs) / len(secs), 2) if secs else 0}",
        "# HELP korrektor_data_bytes Размер папки данных", "# TYPE korrektor_data_bytes gauge", f"korrektor_data_bytes {size}",
        "# HELP korrektor_users_active Активных пользователей", "# TYPE korrektor_users_active gauge", f"korrektor_users_active {nusers}",
        "# HELP korrektor_scrape_timestamp Время сбора", "# TYPE korrektor_scrape_timestamp gauge", f"korrektor_scrape_timestamp {int(_t.time())}",
    ]
    return Response("\n".join(lines) + "\n", media_type="text/plain; version=0.0.4; charset=utf-8")
